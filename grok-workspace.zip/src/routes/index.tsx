import { memo, useEffect, useRef } from "react";
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Home });

type ForgeLabModule = {
  mount: (root: HTMLElement) => Promise<void> | void;
};

async function boot(root: HTMLElement) {
  const spec: string = "/main.js";
  // @ts-expect-error static public module, not in the TS graph
  const mod = (await import(/* @vite-ignore */ spec)) as ForgeLabModule;
  await mod.mount(root);
}

const Home = memo(function Home() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const root = ref.current;
    if (!root) return;
    void boot(root);
  }, []);

  return <div id="app" ref={ref} />;
});
