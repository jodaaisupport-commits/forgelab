export function renderDownloadDialog({ title, body, startLabel, closeLabel, url, filename, note }) {
  const noteHtml = note ? `<p class="muted">${escapeHtml(note)}</p>` : "";
  return `
    <div class="modal-backdrop" data-action="close-download" role="presentation">
      <div class="dialog" role="dialog" aria-modal="true" aria-labelledby="zip-title">
        <h2 id="zip-title">${escapeHtml(title)}</h2>
        <p class="muted">${escapeHtml(body)}</p>
        ${noteHtml}
        <a class="download-link" id="zip-download-link" href="${escapeAttr(url)}" download="${escapeAttr(filename)}" rel="noopener">${escapeHtml(startLabel)}</a>
        <button type="button" class="btn btn-secondary" data-action="close-download">${escapeHtml(closeLabel)}</button>
      </div>
    </div>
  `;
}

export function focusDownloadDialog(root) {
  const link = root.querySelector("#zip-download-link");
  if (link) link.focus();
}

function escapeHtml(value) {
  const amp = "\u0026";
  return String(value)
    .replaceAll("&", `${amp}amp;`)
    .replaceAll("<", `${amp}lt;`)
    .replaceAll(">", `${amp}gt;`)
    .replaceAll('"', `${amp}quot;`);
}

function escapeAttr(value) {
  return escapeHtml(value).replaceAll("'", `${"\u0026"}#39;`);
}
