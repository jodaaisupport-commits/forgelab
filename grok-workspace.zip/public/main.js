import {
  hydrate,
  getState,
  subscribe,
  patch,
  setView,
  pushToast,
  pushActivity,
  startTrainingLoop,
  createTrainingFromWizard,
  addDatasetFromFile,
  currentUser,
  isAdmin,
  hadHydrateWarning,
} from "./state.js";
import {
  VIEWS,
  MAX_UPLOAD_BYTES,
  detectFileKind,
  emptyWizard,
} from "./data.js";
import {
  validateRegister,
  validateLogin,
  createUser,
  verifyPassword,
  findUserByEmail,
} from "./auth.js";
import { CONNECTORS, connectConnector, disconnectConnector, syncConnector } from "./connectors.js";
import {
  renderApp,
  setDict,
  t,
  patchTrainingProgress,
  defaultChat,
  playgroundReply,
} from "./ui.js";
import { prepareProjectZip, getPreparedZip } from "./export.js";
import { focusDownloadDialog } from "./download-ui.js";

let root = null;
let sending = false;
let booted = false;

export async function mount(host) {
  if (!host) return;
  root = host;
  if (booted && host.childElementCount) return;
  booted = true;

  await loadLocale();
  const { warning } = await hydrate();
  startTrainingLoop();
  bind(host);
  paint();
  if (warning || hadHydrateWarning()) pushToast("toast.loadError", "danger");
  void prepareProjectZip();
  registerWorker();
}

async function loadLocale() {
  try {
    const res = await fetch(new URL("./locales/de.json", import.meta.url), { cache: "no-store" });
    if (!res.ok) throw new Error("locale");
    setDict(await res.json());
  } catch {
    setDict({});
  }
}

function paint() {
  if (!root) return;
  const active = document.activeElement;
  const id = active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement ? active.id : "";
  const start = active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement ? active.selectionStart : null;
  const end = active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement ? active.selectionEnd : null;
  renderApp(root);
  if (id) {
    const next = root.querySelector(`#${CSS.escape(id)}`);
    if (next instanceof HTMLInputElement || next instanceof HTMLTextAreaElement) {
      next.focus();
      if (start != null && end != null && typeof next.setSelectionRange === "function") {
        try {
          next.setSelectionRange(start, end);
        } catch {
          /* range inputs */
        }
      }
    }
  }
  const log = root.querySelector("#chat-log");
  if (log) log.scrollTop = log.scrollHeight;
  if (getState().ui.download) focusDownloadDialog(root);
}

function bind(host) {
  if (host.dataset.bound === "1") return;
  host.dataset.bound = "1";
  host.addEventListener("click", onClick);
  host.addEventListener("submit", onSubmit);
  host.addEventListener("input", onInput);
  host.addEventListener("change", onChange);
  document.addEventListener("keydown", onKey);
  subscribe(() => paint());
  globalThis.addEventListener("forgelab:progress", (event) => {
    if (!root) return;
    const state = getState();
    if (state.view === VIEWS.training) {
      patchTrainingProgress(root, event.detail || state.runs);
    }
  });
}

function onKey(event) {
  if (event.key !== "Escape") return;
  const state = getState();
  if (state.ui.download) {
    patch((s) => {
      s.ui.download = null;
    });
  } else if (state.ui.confirm) {
    patch((s) => {
      s.ui.confirm = null;
    });
  } else if (state.ui.sidebarOpen) {
    patch((s) => {
      s.ui.sidebarOpen = false;
    });
  }
}

function actionTarget(event) {
  return event.target.closest("[data-action]");
}

function onClick(event) {
  const link = event.target.closest("a[href]");
  if (link && link.id === "zip-download-link") return;

  const el = actionTarget(event);
  if (!el) return;
  const action = el.dataset.action;
  const id = el.dataset.id;
  const state = getState();

  switch (action) {
    case "auth-mode":
      patch((s) => {
        s.ui.authMode = el.dataset.mode || "login";
      });
      break;
    case "nav":
      go(el.dataset.view);
      break;
    case "toggle-sidebar":
      patch((s) => {
        s.ui.sidebarOpen = !s.ui.sidebarOpen;
      });
      break;
    case "close-sidebar":
      patch((s) => {
        s.ui.sidebarOpen = false;
      });
      break;
    case "logout":
      patch((s) => {
        s.session = null;
        s.view = VIEWS.overview;
      });
      pushToast("toast.loggedOut", "info");
      break;
    case "open-wizard":
      patch((s) => {
        s.wizard = emptyWizard();
        s.view = VIEWS.wizard;
        s.ui.sidebarOpen = false;
      });
      break;
    case "open-model":
      patch((s) => {
        s.ui.selectedModelId = id;
        s.view = VIEWS.modelDetail;
      });
      {
        const model = state.models.find((m) => m.id === id);
        if (model) pushToast("toast.modelOpened", "info", { name: model.name });
      }
      break;
    case "use-playground":
      patch((s) => {
        s.ui.playgroundModelId = id;
        s.view = VIEWS.playground;
        s.ui.sidebarOpen = false;
      });
      {
        const model = state.models.find((m) => m.id === id);
        if (model) pushToast("toast.playground", "success", { name: model.name });
      }
      break;
    case "model-filter":
      patch((s) => {
        s.ui.modelStatus = el.dataset.filter || "all";
      });
      break;
    case "wizard-next":
      captureWizard();
      wizardNext();
      break;
    case "wizard-back":
      captureWizard();
      patch((s) => {
        s.wizard.step = Math.max(1, s.wizard.step - 1);
      });
      break;
    case "wizard-start":
      captureWizard();
      startWizard();
      break;
    case "wizard-type":
      patch((s) => {
        s.wizard.type = id;
      });
      break;
    case "wizard-base":
      patch((s) => {
        s.wizard.baseModelId = id;
      });
      break;
    case "wizard-dataset":
      patch((s) => {
        const set = new Set(s.wizard.datasetIds);
        if (set.has(id)) set.delete(id);
        else set.add(id);
        s.wizard.datasetIds = [...set];
      });
      break;
    case "wizard-hw":
      patch((s) => {
        s.wizard.hardware = id;
      });
      break;
    case "connect":
      patch((s) => {
        s.connectors = connectConnector(s.connectors, id);
      });
      pushToast("connectors.toast.connected", "success", { name: connectorName(id) });
      break;
    case "disconnect":
      patch((s) => {
        s.connectors = disconnectConnector(s.connectors, id);
      });
      pushToast("connectors.toast.disconnected", "info", { name: connectorName(id) });
      break;
    case "sync": {
      const result = syncConnector(state.connectors, id);
      if (!result.ok) {
        pushToast("connectors.toast.blocked", "danger");
        break;
      }
      patch((s) => {
        s.connectors = result.state;
      });
      pushToast("connectors.toast.synced", "success", { name: connectorName(id) });
      break;
    }
    case "toggle-role":
      changeRole(id);
      break;
    case "coming-soon":
      pushToast("settings.comingSoon", "info");
      break;
    case "confirm-delete-model":
      patch((s) => {
        s.ui.confirm = { titleKey: "confirm.deleteModel", okAction: "delete-model", id };
      });
      break;
    case "confirm-delete-dataset":
      patch((s) => {
        s.ui.confirm = { titleKey: "confirm.deleteDataset", okAction: "delete-dataset", id };
      });
      break;
    case "delete-model":
      patch((s) => {
        s.models = s.models.filter((m) => m.id !== id);
        s.runs = s.runs.filter((r) => r.modelId !== id);
        s.ui.confirm = null;
        s.view = VIEWS.models;
      });
      pushToast("models.deleted", "info");
      break;
    case "delete-dataset":
      patch((s) => {
        s.datasets = s.datasets.filter((d) => d.id !== id);
        s.ui.confirm = null;
      });
      pushToast("datasets.deleted", "info");
      break;
    case "close-confirm":
      patch((s) => {
        s.ui.confirm = null;
      });
      break;
    case "close-download":
      if (event.target === el || event.target.closest("[data-action='close-download']") === el) {
        if (event.target.closest(".dialog") && el.classList.contains("modal-backdrop")) return;
        patch((s) => {
          s.ui.download = null;
        });
      }
      break;
    case "export-zip":
      event.preventDefault();
      void handleExport(true);
      break;
    case "pick-upload":
      root.querySelector('input[data-action="upload-dataset"]')?.click();
      break;
    case "suggest":
      void sendChat(el.dataset.text || "");
      break;
    case "notify":
      break;
    default:
      break;
  }
}

function go(view) {
  if (!view) return;
  if (view === VIEWS.admin && !isAdmin()) {
    setView(VIEWS.admin);
    return;
  }
  setView(view);
}

function connectorName(id) {
  return CONNECTORS.find((c) => c.id === id)?.name || id;
}

function changeRole(userId) {
  const me = currentUser();
  const target = getState().users.find((u) => u.id === userId);
  if (!me || !target) return;
  if (me.id === target.id && target.role === "admin") {
    pushToast("admin.selfRole", "danger");
    return;
  }
  patch((s) => {
    const user = s.users.find((u) => u.id === userId);
    if (user) user.role = user.role === "admin" ? "member" : "admin";
  });
  pushToast("admin.roleChanged", "success");
}

function captureWizard() {
  if (!root) return;
  const s = getState();
  const name = root.querySelector('[name="wizard-name"]');
  const desc = root.querySelector('[name="wizard-desc"]');
  const epochs = root.querySelector('[name="wizard-epochs"]');
  const lr = root.querySelector('[name="wizard-lr"]');
  const vis = root.querySelector('[name="wizard-vis"]');
  if (name) s.wizard.name = name.value;
  if (desc) s.wizard.description = desc.value;
  if (epochs) s.wizard.epochs = Number(epochs.value) || 3;
  if (lr) s.wizard.learningRate = lr.value;
  if (vis) s.wizard.visibility = vis.value;
}

function wizardNext() {
  const w = getState().wizard;
  if (w.step === 1 && !w.name.trim()) {
    pushToast("wizard.nameRequired", "danger");
    return;
  }
  if (w.step === 3 && !w.datasetIds.length) {
    pushToast("wizard.datasetRequired", "danger");
    return;
  }
  patch((s) => {
    s.wizard.step = Math.min(4, s.wizard.step + 1);
  });
}

function startWizard() {
  const w = getState().wizard;
  if (!w.name.trim()) {
    pushToast("wizard.nameRequired", "danger");
    return;
  }
  if (!w.datasetIds.length) {
    pushToast("wizard.datasetRequired", "danger");
    return;
  }
  createTrainingFromWizard(w);
  pushToast("toast.trainingStarted", "success");
}

function onInput(event) {
  const el = event.target;
  if (!(el instanceof HTMLInputElement) && !(el instanceof HTMLTextAreaElement) && !(el instanceof HTMLSelectElement)) {
    return;
  }
  if (el.dataset.action === "model-query") {
    patch((s) => {
      s.ui.modelQuery = el.value;
    });
    return;
  }
  if (el.dataset.action === "playground-temp") {
    patch((s) => {
      s.ui.playgroundTemp = Number(el.value);
    });
  }
  if (el.dataset.action === "playground-tokens") {
    getState().ui.playgroundTokens = Number(el.value) || 512;
  }
}

function onChange(event) {
  const el = event.target;
  if (!(el instanceof HTMLInputElement) && !(el instanceof HTMLSelectElement)) return;
  if (el.dataset.action === "model-query") {
    patch((s) => {
      s.ui.modelQuery = el.value;
    });
  }
  if (el.dataset.action === "playground-model") {
    patch((s) => {
      s.ui.playgroundModelId = el.value;
    });
  }
  if (el.dataset.action === "playground-tokens") {
    patch((s) => {
      s.ui.playgroundTokens = Number(el.value) || 512;
    });
  }
  if (el.dataset.action === "notify") {
    patch((s) => {
      s.settings.notifications[el.dataset.id] = el.checked;
    });
  }
  if (el.dataset.action === "upload-dataset" && el.files?.[0]) {
    void handleUpload(el.files[0]);
    el.value = "";
  }
}

async function onSubmit(event) {
  const form = event.target;
  if (!(form instanceof HTMLFormElement)) return;
  event.preventDefault();
  const kind = form.dataset.form;
  if (kind === "login") await submitLogin(form);
  if (kind === "register") await submitRegister(form);
  if (kind === "chat") {
    const input = form.querySelector("#chat-input");
    const text = input instanceof HTMLInputElement ? input.value : "";
    void sendChat(text);
  }
  if (kind === "settings") saveSettings(form);
}

function showFormError(form, messageKey, field) {
  const box = form.querySelector("[data-error-form]");
  if (box) {
    box.hidden = !messageKey;
    box.textContent = messageKey ? t(messageKey) : "";
  }
  form.querySelectorAll("[data-error-for]").forEach((node) => {
    const key = node.getAttribute("data-error-for");
    const msg = field && key === field ? t(messageKey) : "";
    node.hidden = !msg;
    node.textContent = msg;
  });
}

function setBusy(form, busy) {
  const btn = form.querySelector("[data-submit]");
  if (!(btn instanceof HTMLButtonElement)) return;
  btn.disabled = busy;
  if (busy) {
    btn.dataset.label = btn.innerHTML;
    btn.innerHTML = `<span class="spinner" aria-hidden="true"></span> ${t("auth.busy")}`;
  } else if (btn.dataset.label) {
    btn.innerHTML = btn.dataset.label;
  }
}

async function submitLogin(form) {
  const data = Object.fromEntries(new FormData(form).entries());
  const errors = validateLogin({ email: String(data.email || ""), password: String(data.password || "") });
  const first = Object.keys(errors)[0];
  if (first) {
    showFormError(form, errors[first], first);
    return;
  }
  setBusy(form, true);
  try {
    const user = findUserByEmail(getState().users, String(data.email));
    if (!user || !(await verifyPassword(String(data.password), user))) {
      showFormError(form, "auth.error.invalid");
      return;
    }
    patch((s) => {
      s.session = { userId: user.id };
      s.view = VIEWS.overview;
    });
  } finally {
    setBusy(form, false);
  }
}

async function submitRegister(form) {
  const data = Object.fromEntries(new FormData(form).entries());
  const payload = {
    name: String(data.name || ""),
    email: String(data.email || ""),
    password: String(data.password || ""),
    confirm: String(data.confirm || ""),
  };
  const errors = validateRegister(payload);
  const first = Object.keys(errors)[0];
  if (first) {
    showFormError(form, errors[first], first);
    return;
  }
  if (findUserByEmail(getState().users, payload.email)) {
    showFormError(form, "auth.error.duplicate", "email");
    return;
  }
  setBusy(form, true);
  try {
    const isFirst = getState().users.length === 0;
    const user = await createUser({ ...payload, isFirst });
    patch((s) => {
      s.users = [...s.users, user];
      s.session = { userId: user.id };
      s.view = VIEWS.overview;
    });
  } finally {
    setBusy(form, false);
  }
}

function saveSettings(form) {
  const data = new FormData(form);
  patch((s) => {
    s.settings.workspaceName = String(data.get("workspace") || s.settings.workspaceName).trim() || s.settings.workspaceName;
    const me = currentUser();
    if (me) {
      me.name = String(data.get("username") || me.name).trim() || me.name;
    }
  });
  pushToast("settings.saved", "success");
}

async function sendChat(text) {
  const message = String(text || "").trim();
  if (!message || sending) return;
  const state = getState();
  const model = state.models.find((m) => m.id === state.ui.playgroundModelId) || state.models[0];
  if (!model) return;
  sending = true;
  patch((s) => {
    const history = s.chats[model.id] || defaultChat(model);
    s.chats[model.id] = [...history, { role: "user", text: message }];
  });
  const submit = root?.querySelector('.composer [type="submit"]');
  if (submit instanceof HTMLButtonElement) submit.disabled = true;
  await new Promise((resolve) => setTimeout(resolve, 550 + Math.random() * 400));
  patch((s) => {
    const history = s.chats[model.id] || [];
    s.chats[model.id] = [...history, { role: "assistant", text: playgroundReply(model, message) }];
  });
  sending = false;
}

async function handleUpload(file) {
  if (file.size > MAX_UPLOAD_BYTES) {
    pushToast("datasets.tooLarge", "danger");
    return;
  }
  const kind = detectFileKind(file);
  const quality = 85 + Math.round(Math.random() * 15);
  addDatasetFromFile(file, kind, quality);
  pushActivity("activity.datasetUploaded", "success");
  pushToast("datasets.uploaded", "success");
}

async function handleExport(fromGesture) {
  const ready = getPreparedZip();
  if (ready) {
    showZipDialog(ready, fromGesture);
    return;
  }
  const btn = root?.querySelector('[data-action="export-zip"]');
  if (btn instanceof HTMLButtonElement) btn.disabled = true;
  try {
    const zip = await prepareProjectZip();
    showZipDialog(zip, false);
  } finally {
    if (btn instanceof HTMLButtonElement) btn.disabled = false;
  }
}

function showZipDialog(zip, auto) {
  patch((s) => {
    s.ui.download = {
      title: t("export.readyTitle"),
      body: t("export.readyBody"),
      startLabel: t("export.start"),
      closeLabel: t("export.close"),
      url: zip.url,
      filename: zip.filename,
      note: zip.missing ? t("export.failed") : "",
    };
    s.ui.sidebarOpen = false;
  });
  if (auto) {
    requestAnimationFrame(() => {
      const link = root?.querySelector("#zip-download-link");
      if (link instanceof HTMLAnchorElement) link.click();
    });
  }
}

function registerWorker() {
  if (!("serviceWorker" in navigator)) return;
  const proto = location.protocol;
  if (proto !== "http:" && proto !== "https:") return;
  navigator.serviceWorker.register("/sw.js").catch(() => {});
}

if (typeof document !== "undefined") {
  const host = globalThis.__FORGELAB_MOUNT || document.getElementById("app");
  if (host instanceof HTMLElement) void mount(host);
}
