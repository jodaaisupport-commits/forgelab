import { icon } from "./icons.js";
import {
  getState,
  currentUser,
  isAdmin,
  stats,
} from "./state.js";
import {
  VIEWS,
  MODEL_TYPES,
  BASE_MODELS,
  HARDWARE,
  STATUS,
} from "./data.js";
import { CONNECTORS } from "./connectors.js";
import { renderDownloadDialog } from "./download-ui.js";

let dict = {};

export function setDict(next) {
  dict = next || {};
}

export function t(key, vars = {}) {
  const template = dict[key] ?? key;
  return String(template).replace(/\{(\w+)\}/g, (_, name) =>
    vars[name] == null ? "" : String(vars[name]),
  );
}

export function escapeHtml(value) {
  const amp = "\u0026";
  return String(value ?? "")
    .replaceAll("&", `${amp}amp;`)
    .replaceAll("<", `${amp}lt;`)
    .replaceAll(">", `${amp}gt;`)
    .replaceAll('"', `${amp}quot;`);
}

function formatNumber(value) {
  return new Intl.NumberFormat("de-DE").format(value);
}

function formatPercent(value) {
  return `${new Intl.NumberFormat("de-DE", { maximumFractionDigits: 1 }).format(value)} %`;
}

function formatBytes(bytes) {
  if (bytes >= 1024 * 1024 * 1024) {
    return `${new Intl.NumberFormat("de-DE", { maximumFractionDigits: 1 }).format(bytes / (1024 * 1024 * 1024))} GB`;
  }
  if (bytes >= 1024 * 1024) {
    return `${new Intl.NumberFormat("de-DE", { maximumFractionDigits: 1 }).format(bytes / (1024 * 1024))} MB`;
  }
  return `${new Intl.NumberFormat("de-DE", { maximumFractionDigits: 0 }).format(bytes / 1024)} KB`;
}

function formatDate(iso) {
  if (!iso) return "–";
  try {
    return new Intl.DateTimeFormat("de-DE", { dateStyle: "medium" }).format(new Date(iso));
  } catch {
    return iso;
  }
}

function formatDateTime(iso) {
  if (!iso) return t("connectors.never");
  try {
    return new Intl.DateTimeFormat("de-DE", { dateStyle: "medium", timeStyle: "short" }).format(
      new Date(iso),
    );
  } catch {
    return iso;
  }
}

function typeLabel(id) {
  return t(`types.${id === "text" ? "text" : id}`);
}

function statusBadge(status) {
  const label = t(`status.${status}`);
  return `<span class="badge badge-${escapeHtml(status)}">${escapeHtml(label)}</span>`;
}

function initials(name) {
  return String(name || "?")
    .split(" ")
    .map((p) => p[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

const NAV = [
  { view: VIEWS.overview, key: "nav.overview", icon: "overview" },
  { view: VIEWS.models, key: "nav.models", icon: "models" },
  { view: VIEWS.datasets, key: "nav.datasets", icon: "datasets" },
  { view: VIEWS.training, key: "nav.training", icon: "training" },
  { view: VIEWS.playground, key: "nav.playground", icon: "playground" },
  { view: VIEWS.connectors, key: "nav.connectors", icon: "connectors" },
  { view: VIEWS.admin, key: "nav.admin", icon: "admin" },
  { view: VIEWS.settings, key: "nav.settings", icon: "settings" },
];

function logoImg() {
  return `<img class="brand-mark" src="/icon.svg" alt="" width="40" height="40" />`;
}

export function renderApp(root) {
  const state = getState();
  const user = currentUser();
  if (!user) {
    root.innerHTML = renderAuth(state);
    return;
  }
  root.innerHTML = renderShell(state, user);
}

function renderAuth(state) {
  const mode = state.ui.authMode === "register" ? "register" : "login";
  const register = mode === "register";
  return `
    <div class="auth-layout">
      <section class="auth-panel">
        <div class="brand-row">
          ${logoImg()}
          <div class="brand-copy">
            <strong>${escapeHtml(t("app.mark"))}</strong>
            <span>${escapeHtml(t("auth.subtitle"))}</span>
          </div>
        </div>
        <div class="auth-tabs" role="tablist">
          <button type="button" role="tab" aria-selected="${!register}" data-action="auth-mode" data-mode="login">${escapeHtml(t("auth.signIn"))}</button>
          <button type="button" role="tab" aria-selected="${register}" data-action="auth-mode" data-mode="register">${escapeHtml(t("auth.register"))}</button>
        </div>
        <h1>${escapeHtml(register ? t("auth.registerTitle") : t("auth.welcomeTitle"))}</h1>
        <p>${escapeHtml(register ? t("auth.registerBody") : t("auth.welcomeBody"))}</p>
        <form class="auth-form" data-form="${register ? "register" : "login"}" novalidate>
          ${register ? field("name", t("auth.name"), "text", "name") : ""}
          ${field("email", t("auth.email"), "email", "email")}
          ${field("password", t("auth.password"), "password", "current-password")}
          ${register ? field("confirm", t("auth.confirmPassword"), "password", "new-password") : ""}
          <p class="field-error" data-error-form hidden></p>
          <button class="btn btn-primary" type="submit" data-submit>
            ${escapeHtml(register ? t("auth.createAccount") : t("auth.signIn"))}
          </button>
        </form>
        <p class="auth-note">${escapeHtml(t("auth.securityNote"))}</p>
        <p class="auth-demo">${escapeHtml(t("auth.demoBackend"))}</p>
      </section>
      <aside class="auth-aside" aria-hidden="true">
        <div class="aside-card">
          <p class="eyebrow">${escapeHtml(t("dash.eyebrow"))}</p>
          <h2>${escapeHtml(t("dash.title"))}</h2>
          <p class="muted">${escapeHtml(t("dash.body"))}</p>
        </div>
      </aside>
    </div>
  `;
}

function field(id, label, type, autocomplete) {
  return `
    <label class="field" for="${id}">
      <span>${escapeHtml(label)}</span>
      <input class="input" id="${id}" name="${id}" type="${type}" autocomplete="${autocomplete}" required />
      <small class="field-error" data-error-for="${id}" hidden></small>
    </label>
  `;
}

function renderShell(state, user) {
  const view = state.view;
  const title = pageTitle(view);
  return `
    <a class="skip-link" href="#main">${escapeHtml(t("nav.skip"))}</a>
    <div class="app-shell">
      <div class="backdrop${state.ui.sidebarOpen ? " show" : ""}" data-action="close-sidebar"></div>
      ${renderSidebar(state, user)}
      <div class="main-col">
        <header class="topbar">
          <button class="btn btn-ghost btn-icon menu-btn" type="button" data-action="toggle-sidebar" aria-label="${escapeHtml(t("nav.openMenu"))}">${icon("menu")}</button>
          <h1>${escapeHtml(title)}</h1>
          ${viewAction(view)}
        </header>
        <main id="main" class="content">${renderView(state, user)}</main>
      </div>
    </div>
    <div class="toasts" aria-live="polite" aria-label="${escapeHtml(t("a11y.toasts"))}">
      ${state.ui.toasts.map((toast) => `<div class="toast ${toast.tone}">${escapeHtml(t(toast.message, toast.vars || {}))}</div>`).join("")}
    </div>
    ${state.ui.download ? renderDownloadDialog(state.ui.download) : ""}
    ${state.ui.confirm ? renderConfirm(state.ui.confirm) : ""}
  `;
}

function pageTitle(view) {
  if (view === VIEWS.wizard) return t("wizard.title");
  if (view === VIEWS.modelDetail) return t("detail.title");
  const item = NAV.find((n) => n.view === view);
  return item ? t(item.key) : t("app.name");
}

function viewAction(view) {
  if (view === VIEWS.overview || view === VIEWS.models) {
    return `<button class="btn btn-primary" type="button" data-action="open-wizard">${icon("plus", { size: 16 })} ${escapeHtml(t("dash.create"))}</button>`;
  }
  return "";
}

function renderSidebar(state, user) {
  const used = state.models.length;
  const limit = state.settings.usageLimit || 10;
  const pct = Math.min(100, Math.round((used / limit) * 100));
  return `
    <aside class="sidebar${state.ui.sidebarOpen ? " open" : ""}" aria-label="${escapeHtml(t("app.name"))}">
      <div class="sidebar-brand">
        ${logoImg()}
        <div>
          <strong>${escapeHtml(t("app.mark"))}</strong>
          <div class="workspace-name">${escapeHtml(state.settings.workspaceName || t("app.workspaceDefault"))}</div>
        </div>
      </div>
      <div class="plan-card">
        <header>
          <span>${escapeHtml(t("app.plan"))}</span>
          <span class="badge badge-demo">${escapeHtml(t("app.demo"))}</span>
        </header>
        <div class="usage-bar" aria-hidden="true"><span style="width:${pct}%"></span></div>
        <p>${escapeHtml(t("app.usage", { used, limit }))}</p>
        <p>${escapeHtml(t("app.renews", { date: formatDate(state.settings.renewsAt) }))}</p>
      </div>
      <ul class="nav-list">
        ${NAV.map((item) => {
          const active = state.view === item.view || (item.view === VIEWS.models && state.view === VIEWS.modelDetail);
          return `<li><button class="nav-btn${active ? " active" : ""}" type="button" data-action="nav" data-view="${item.view}" ${active ? 'aria-current="page"' : ""}>${icon(item.icon, { size: 18 })} ${escapeHtml(t(item.key))}</button></li>`;
        }).join("")}
        <li><button class="nav-btn" type="button" data-action="export-zip">${icon("download", { size: 18 })} ${escapeHtml(t("nav.export"))}</button></li>
      </ul>
      <div class="sidebar-user">
        <div class="user-chip">
          <div class="avatar">${escapeHtml(initials(user.name))}</div>
          <div>
            <strong>${escapeHtml(user.name)}</strong>
            <span>${escapeHtml(user.role === "admin" ? t("admin.role.admin") : t("admin.role.member"))}</span>
          </div>
        </div>
        <button class="btn btn-secondary" type="button" data-action="logout">${icon("logout", { size: 16 })} ${escapeHtml(t("nav.logout"))}</button>
      </div>
    </aside>
  `;
}

function renderView(state, user) {
  switch (state.view) {
    case VIEWS.overview:
      return renderOverview(state);
    case VIEWS.models:
      return renderModels(state);
    case VIEWS.modelDetail:
      return renderModelDetail(state);
    case VIEWS.wizard:
      return renderWizard(state);
    case VIEWS.datasets:
      return renderDatasets(state);
    case VIEWS.training:
      return renderTraining(state);
    case VIEWS.playground:
      return renderPlayground(state);
    case VIEWS.connectors:
      return renderConnectors(state);
    case VIEWS.admin:
      return isAdmin() ? renderAdmin(state) : renderForbidden();
    case VIEWS.settings:
      return renderSettings(state, user);
    default:
      return renderOverview(state);
  }
}

function renderOverview(state) {
  const s = stats();
  const recent = [...state.models].sort((a, b) => String(b.updatedAt).localeCompare(a.updatedAt)).slice(0, 3);
  const runs = state.runs.slice(0, 3);
  return `
    <section class="hero">
      <div>
        <p class="eyebrow">${escapeHtml(t("dash.eyebrow"))}</p>
        <h2>${escapeHtml(t("dash.title"))}</h2>
        <p>${escapeHtml(t("dash.body"))}</p>
        <div class="hero-actions">
          <button class="btn btn-primary" type="button" data-action="open-wizard">${icon("plus", { size: 16 })} ${escapeHtml(t("dash.create"))}</button>
          <button class="btn btn-secondary" type="button" data-action="nav" data-view="${VIEWS.playground}">${escapeHtml(t("dash.secondary"))}</button>
        </div>
      </div>
      <div class="hero-visual">${nodeArt()}</div>
    </section>
    <section class="stats-grid">
      ${statCard("models", formatNumber(s.models), t("dash.stat.models"), t("dash.stat.modelsMeta"), "coral")}
      ${statCard("datasets", formatNumber(s.datasets), t("dash.stat.datasets"), t("dash.stat.datasetsMeta"), "info")}
      ${statCard("activity", formatNumber(s.runs), t("dash.stat.runs"), t("dash.stat.runsMeta"), "success")}
      ${statCard("target", formatPercent(s.bestAccuracy), t("dash.stat.accuracy"), t("dash.stat.accuracyMeta"), "gold")}
    </section>
    <div class="split">
      <section>
        <div class="section-head">
          <h2>${escapeHtml(t("dash.recent"))}</h2>
          <button class="btn btn-ghost" type="button" data-action="nav" data-view="${VIEWS.models}">${escapeHtml(t("dash.viewAll"))}</button>
        </div>
        <div class="card-grid">${recent.map(modelCard).join("") || emptyBlock(t("models.empty"), "open-wizard", t("models.emptyAction"))}</div>
      </section>
      <section>
        <div class="section-head"><h2>${escapeHtml(t("dash.activity"))}</h2></div>
        <ul class="feed">
          ${state.activities.slice(0, 5).map((a) => `<li><span>${escapeHtml(t(a.key))}</span><time datetime="${a.at}">${escapeHtml(formatDateTime(a.at))}</time></li>`).join("")}
        </ul>
      </section>
    </div>
    <section>
      <div class="section-head">
        <h2>${escapeHtml(t("dash.runs"))}</h2>
        <button class="btn btn-ghost" type="button" data-action="nav" data-view="${VIEWS.training}">${escapeHtml(t("dash.viewAll"))}</button>
      </div>
      <div class="card-grid">${runs.map(runCard).join("")}</div>
    </section>
  `;
}

function statCard(ico, value, label, meta, tone) {
  return `
    <article class="stat-card tone-${tone}">
      <header>
        <span>${escapeHtml(label)}</span>
        <span class="icon-wrap">${icon(ico, { size: 18 })}</span>
      </header>
      <strong class="num">${escapeHtml(value)}</strong>
      <p>${escapeHtml(meta)}</p>
    </article>
  `;
}

function nodeArt() {
  return `
    <svg class="node-art" viewBox="0 0 360 180" fill="none" aria-hidden="true">
      <path d="M40 90h280" stroke="#223044" />
      <path d="M80 40l200 100M80 140l200-100" stroke="#223044" />
      <circle cx="80" cy="40" r="8" fill="#ff6a3d" />
      <circle cx="80" cy="140" r="8" fill="#4c9fff" />
      <circle cx="180" cy="90" r="12" fill="#141c28" stroke="#ff6a3d" />
      <circle cx="280" cy="40" r="8" fill="#3dcc8a" />
      <circle cx="280" cy="140" r="8" fill="#e8b84a" />
    </svg>
  `;
}

function modelCard(model) {
  return `
    <article class="model-card">
      <header>
        <div>
          <h3>${escapeHtml(model.name)}</h3>
          <p class="muted">${escapeHtml(typeLabel(model.type))} · ${escapeHtml(model.baseModel)}</p>
        </div>
        ${statusBadge(model.status)}
      </header>
      <p class="muted">${escapeHtml(model.description || t(model.descKey || ""))}</p>
      <div class="meta-row">
        <span>${escapeHtml(t("models.version"))} ${escapeHtml(model.version)}</span>
        <span class="num">${escapeHtml(formatPercent(model.accuracy))}</span>
        <span>${escapeHtml(t(`visibility.${model.visibility}`))}</span>
        <span>${escapeHtml(t("models.downloads", { n: formatNumber(model.downloads) }))}</span>
      </div>
      <div class="card-actions">
        <button class="btn btn-secondary" type="button" data-action="open-model" data-id="${model.id}">${escapeHtml(t("models.open"))}</button>
        <button class="btn btn-ghost" type="button" data-action="use-playground" data-id="${model.id}">${escapeHtml(t("models.usePlayground"))}</button>
      </div>
    </article>
  `;
}

function renderModels(state) {
  const q = (state.ui.modelQuery || "").toLowerCase();
  const filter = state.ui.modelStatus || "all";
  const list = state.models.filter((m) => {
    const matchQ = !q || m.name.toLowerCase().includes(q);
    const matchS = filter === "all" || m.status === filter;
    return matchQ && matchS;
  });
  return `
    <p class="muted">${escapeHtml(t("models.body"))}</p>
    <div class="toolbar">
      <label class="search">
        <span class="sr-only">${escapeHtml(t("models.search"))}</span>
        ${icon("search", { size: 18 })}
        <input class="input" id="model-query" type="search" value="${escapeHtml(state.ui.modelQuery || "")}" placeholder="${escapeHtml(t("models.search"))}" data-action="model-query" />
      </label>
      <div class="chips" role="group">
        ${["all", "ready", "training", "failed"].map((id) => `<button type="button" class="chip" data-action="model-filter" data-filter="${id}" aria-pressed="${filter === id}">${escapeHtml(t("models.filter." + (id === "all" ? "all" : id)))}</button>`).join("")}
      </div>
    </div>
    ${list.length ? `<div class="model-grid">${list.map(modelCard).join("")}</div>` : emptyBlock(t("models.empty"), "open-wizard", t("models.emptyAction"))}
  `;
}

function renderModelDetail(state) {
  const model = state.models.find((m) => m.id === state.ui.selectedModelId);
  if (!model) return emptyBlock(t("models.empty"), "nav", t("nav.models"), VIEWS.models);
  const runs = state.runs.filter((r) => r.modelId === model.id);
  return `
    <button class="btn btn-ghost" type="button" data-action="nav" data-view="${VIEWS.models}">${icon("chevronLeft", { size: 16 })} ${escapeHtml(t("common.back"))}</button>
    <article class="card">
      <header class="section-head">
        <div>
          <h2>${escapeHtml(model.name)}</h2>
          <p class="muted">${escapeHtml(model.description || t(model.descKey || ""))}</p>
        </div>
        ${statusBadge(model.status)}
      </header>
      <div class="meta-row">
        <span>${escapeHtml(typeLabel(model.type))}</span>
        <span>${escapeHtml(model.baseModel)}</span>
        <span>${escapeHtml(model.version)}</span>
        <span class="num">${escapeHtml(formatPercent(model.accuracy))}</span>
        <span>${escapeHtml(t(`visibility.${model.visibility}`))}</span>
      </div>
      <div class="card-actions">
        <button class="btn btn-primary" type="button" data-action="use-playground" data-id="${model.id}">${escapeHtml(t("detail.use"))}</button>
        <button class="btn btn-danger" type="button" data-action="confirm-delete-model" data-id="${model.id}">${escapeHtml(t("models.delete"))}</button>
      </div>
    </article>
    <section>
      <h2>${escapeHtml(t("training.history"))}</h2>
      <div class="card-grid">${runs.map(runCard).join("") || `<p class="muted">${escapeHtml(t("training.empty"))}</p>`}</div>
    </section>
  `;
}

function renderWizard(state) {
  const w = state.wizard;
  const step = w.step;
  return `
    <p class="subtle">${escapeHtml(t("wizard.stepOf", { n: step }))}</p>
    <div class="steps" aria-hidden="true">
      ${[1, 2, 3, 4].map((n) => `<div class="step${n === step ? " current" : ""}${n < step ? " done" : ""}">${escapeHtml(t("wizard.step" + n))}</div>`).join("")}
    </div>
    <div class="wizard">
      ${step === 1 ? wizardBasics(w) : ""}
      ${step === 2 ? wizardBase(w) : ""}
      ${step === 3 ? wizardData(state) : ""}
      ${step === 4 ? wizardConfig(state, w) : ""}
      <div class="card-actions">
        ${step > 1 ? `<button class="btn btn-secondary" type="button" data-action="wizard-back">${escapeHtml(t("wizard.back"))}</button>` : `<button class="btn btn-secondary" type="button" data-action="nav" data-view="${VIEWS.models}">${escapeHtml(t("common.cancel"))}</button>`}
        ${step < 4 ? `<button class="btn btn-primary" type="button" data-action="wizard-next">${escapeHtml(t("wizard.next"))}</button>` : `<button class="btn btn-primary" type="button" data-action="wizard-start">${escapeHtml(t("wizard.start"))}</button>`}
      </div>
    </div>
  `;
}

function wizardBasics(w) {
  return `
    <div class="card stack">
      <label class="field">${escapeHtml(t("wizard.name"))}
        <input class="input" name="wizard-name" value="${escapeHtml(w.name)}" placeholder="${escapeHtml(t("wizard.namePh"))}" />
      </label>
      <label class="field">${escapeHtml(t("wizard.desc"))}
        <textarea class="textarea" name="wizard-desc" placeholder="${escapeHtml(t("wizard.descPh"))}">${escapeHtml(w.description)}</textarea>
      </label>
      <fieldset class="field">
        <legend class="field-label">${escapeHtml(t("wizard.type"))}</legend>
        <div class="choice-grid">
          ${MODEL_TYPES.map((tp) => `<button type="button" class="choice" data-action="wizard-type" data-id="${tp.id}" aria-pressed="${w.type === tp.id}"><strong>${escapeHtml(t(tp.labelKey))}</strong></button>`).join("")}
        </div>
      </fieldset>
    </div>
  `;
}

function wizardBase(w) {
  return `
    <div class="choice-grid">
      ${BASE_MODELS.map((b) => `
        <button type="button" class="choice" data-action="wizard-base" data-id="${b.id}" aria-pressed="${w.baseModelId === b.id}">
          <strong>${escapeHtml(b.name)}</strong>
          <p class="muted">${escapeHtml(b.vendor)} · ${escapeHtml(typeLabel(b.type))}</p>
          <p>${escapeHtml(t(b.descKey))}</p>
        </button>
      `).join("")}
    </div>
  `;
}

function wizardData(state) {
  const selected = new Set(state.wizard.datasetIds);
  return `
    <div class="dataset-grid">
      ${state.datasets.map((ds) => `
        <button type="button" class="choice" data-action="wizard-dataset" data-id="${ds.id}" aria-pressed="${selected.has(ds.id)}">
          <header><strong>${escapeHtml(ds.name)}</strong>${statusBadge("validated")}</header>
          <div class="meta-row">
            <span>${escapeHtml(ds.format)}</span>
            <span>${escapeHtml(t("datasets.rows", { n: formatNumber(ds.rows) }))}</span>
            <span>${escapeHtml(formatBytes(ds.sizeBytes))}</span>
            <span>${escapeHtml(t("common.quality"))} ${ds.quality} %</span>
          </div>
        </button>
      `).join("")}
    </div>
    <div class="check-ok">
      <strong>${escapeHtml(t("wizard.checkOk"))}</strong>
      <p>${escapeHtml(t("wizard.checkDetail"))}</p>
    </div>
  `;
}

function wizardConfig(state, w) {
  const base = BASE_MODELS.find((b) => b.id === w.baseModelId);
  const datasets = state.datasets.filter((d) => w.datasetIds.includes(d.id)).map((d) => d.name).join(", ");
  return `
    <div class="card stack">
      <label class="field">${escapeHtml(t("wizard.epochs"))}
        <input class="input" type="number" min="1" max="20" name="wizard-epochs" value="${escapeHtml(w.epochs)}" />
      </label>
      <label class="field">${escapeHtml(t("wizard.lr"))}
        <input class="input" name="wizard-lr" value="${escapeHtml(w.learningRate)}" />
      </label>
      <label class="field">${escapeHtml(t("wizard.visibility"))}
        <select class="select" name="wizard-vis">
          <option value="private" ${w.visibility === "private" ? "selected" : ""}>${escapeHtml(t("visibility.private"))}</option>
          <option value="public" ${w.visibility === "public" ? "selected" : ""}>${escapeHtml(t("visibility.public"))}</option>
        </select>
      </label>
      <fieldset class="field">
        <legend class="field-label">${escapeHtml(t("wizard.hardware"))}</legend>
        ${HARDWARE.map((h) => `
          <button type="button" class="choice" data-action="wizard-hw" data-id="${h.id}" aria-pressed="${w.hardware === h.id}">
            <strong>${escapeHtml(t(h.labelKey))}</strong>
            <p class="muted">${escapeHtml(t(h.hintKey))}</p>
          </button>
        `).join("")}
      </fieldset>
      <div>
        <h3>${escapeHtml(t("wizard.summary"))}</h3>
        <div class="summary-list">
          <div><span class="muted">${escapeHtml(t("wizard.name"))}</span><strong>${escapeHtml(w.name || "–")}</strong></div>
          <div><span class="muted">${escapeHtml(t("wizard.type"))}</span><strong>${escapeHtml(typeLabel(w.type))}</strong></div>
          <div><span class="muted">${escapeHtml(t("models.base"))}</span><strong>${escapeHtml(base?.name || "")}</strong></div>
          <div><span class="muted">${escapeHtml(t("nav.datasets"))}</span><strong>${escapeHtml(datasets || "–")}</strong></div>
          <div><span class="muted">${escapeHtml(t("wizard.hardware"))}</span><strong>${escapeHtml(t(w.hardware === "gpu" ? "hardware.gpu" : "hardware.cpu"))}</strong></div>
        </div>
      </div>
    </div>
  `;
}

function renderDatasets(state) {
  const avg = state.datasets.length
    ? Math.round(state.datasets.reduce((n, d) => n + d.quality, 0) / state.datasets.length)
    : 0;
  const validated = state.datasets.filter((d) => d.status === "validated").length;
  return `
    <p class="muted">${escapeHtml(t("datasets.body"))}</p>
    <div class="stats-grid">
      ${statCard("target", formatPercent(avg), t("datasets.avgQuality"), t("datasets.quality"), "success")}
      ${statCard("check", `${validated}/${state.datasets.length}`, t("datasets.validatedShare"), t("status.validated"), "info")}
    </div>
    <label class="upload">
      ${icon("upload", { size: 28 })}
      <strong>${escapeHtml(t("datasets.drop"))}</strong>
      <span class="muted">${escapeHtml(t("datasets.formats"))} · ${escapeHtml(t("datasets.max"))}</span>
      <input type="file" accept=".json,.jsonl,.csv,.txt,image/*" data-action="upload-dataset" />
    </label>
    ${state.datasets.length ? `<div class="dataset-grid">${state.datasets.map(datasetCard).join("")}</div>` : emptyBlock(t("datasets.empty"), "pick-upload", t("datasets.upload"))}
  `;
}

function datasetCard(ds) {
  const count = ds.kind === "image"
    ? t("datasets.filesCount", { n: formatNumber(ds.files || ds.rows) })
    : t("datasets.rows", { n: formatNumber(ds.rows) });
  return `
    <article class="dataset-card">
      <header>
        <div>
          <h3>${escapeHtml(ds.name)}</h3>
          <p class="muted">${escapeHtml(ds.format)}</p>
        </div>
        ${statusBadge("validated")}
      </header>
      <div class="meta-row">
        <span>${escapeHtml(count)}</span>
        <span>${escapeHtml(formatBytes(ds.sizeBytes))}</span>
        <span>${escapeHtml(t("common.quality"))} ${ds.quality} %</span>
      </div>
      <div class="card-actions">
        <button class="btn btn-ghost" type="button" data-action="confirm-delete-dataset" data-id="${ds.id}">${escapeHtml(t("datasets.delete"))}</button>
      </div>
    </article>
  `;
}

function renderTraining(state) {
  const active = state.runs.find((r) => r.status === STATUS.running);
  const rest = state.runs.filter((r) => r !== active);
  return `
    <p class="muted">${escapeHtml(t("training.body"))}</p>
    ${active ? runCard(active, true) : ""}
    <div class="card-grid">
      ${rest.map((r) => runCard(r, false)).join("") || (!active ? emptyBlock(t("training.empty"), "open-wizard", t("training.emptyAction")) : "")}
    </div>
  `;
}

function runCard(run, featured = run.status === STATUS.running) {
  const mode = run.hardware === "gpu" ? t("training.modeGpu") : t("training.modeCpu");
  return `
    <article class="run-card${featured ? " active-run" : ""}" data-run-id="${run.id}">
      <header>
        <div>
          <h3>${escapeHtml(run.modelName)} ${escapeHtml(run.version)}</h3>
          <p class="muted">${featured && run.status === STATUS.running ? escapeHtml(t("training.active")) : escapeHtml(mode)}</p>
        </div>
        ${statusBadge(run.status === STATUS.running ? "running" : run.status)}
      </header>
      <div class="progress" aria-label="${escapeHtml(t("training.progress"))}"><span data-progress="${run.id}" style="width:${run.progress}%"></span></div>
      <p class="num muted" data-pct="${run.id}">${escapeHtml(formatNumber(Math.round(run.progress)))} %</p>
      <div class="metric-row">
        <div class="metric"><span>${escapeHtml(t("training.lastAccuracy"))}</span><strong class="num" data-acc="${run.id}">${escapeHtml(formatPercent(run.accuracy))}</strong></div>
        <div class="metric"><span>${escapeHtml(t("training.loss"))}</span><strong class="num" data-loss="${run.id}">${escapeHtml(String(run.loss))}</strong></div>
        <div class="metric"><span>${escapeHtml(t("training.duration"))}</span><strong class="num" data-dur="${run.id}">${escapeHtml(t("training.minutes", { n: run.durationMin }))}</strong></div>
        <div class="metric"><span>${escapeHtml(t("wizard.hardware"))}</span><strong>${escapeHtml(mode)}</strong></div>
      </div>
    </article>
  `;
}

export function patchTrainingProgress(root, runs) {
  for (const run of runs) {
    const bar = root.querySelector(`[data-progress="${run.id}"]`);
    if (bar) bar.style.width = `${run.progress}%`;
    const acc = root.querySelector(`[data-acc="${run.id}"]`);
    if (acc) acc.textContent = formatPercent(run.accuracy);
    const loss = root.querySelector(`[data-loss="${run.id}"]`);
    if (loss) loss.textContent = String(run.loss);
    const dur = root.querySelector(`[data-dur="${run.id}"]`);
    if (dur) dur.textContent = t("training.minutes", { n: run.durationMin });
    const pct = root.querySelector(`[data-pct="${run.id}"]`);
    if (pct) pct.textContent = `${formatNumber(Math.round(run.progress))} %`;
  }
}

function renderPlayground(state) {
  const models = state.models;
  const selectedId = state.ui.playgroundModelId || models[0]?.id;
  const model = models.find((m) => m.id === selectedId) || models[0];
  if (!model) return emptyBlock(t("models.empty"), "open-wizard", t("models.emptyAction"));
  const chat = state.chats[model.id] || defaultChat(model);
  return `
    <p class="muted">${escapeHtml(t("playground.body"))}</p>
    <div class="card stack">
      <label class="field">${escapeHtml(t("playground.model"))}
        <select class="select" data-action="playground-model">
          ${models.map((m) => `<option value="${m.id}" ${m.id === model.id ? "selected" : ""}>${escapeHtml(m.name)}</option>`).join("")}
        </select>
      </label>
      <label class="field">${escapeHtml(t("playground.temp"))}: <span class="num">${state.ui.playgroundTemp}</span>
        <input type="range" min="0" max="1" step="0.1" value="${state.ui.playgroundTemp}" data-action="playground-temp" />
      </label>
      <label class="field">${escapeHtml(t("playground.tokens"))}
        <input class="input" type="number" min="64" max="4096" value="${state.ui.playgroundTokens}" data-action="playground-tokens" />
      </label>
    </div>
    <div class="chat" id="chat-log">
      ${chat.map((msg) => `<div class="bubble ${msg.role}"><strong>${escapeHtml(msg.role === "user" ? t("playground.you") : model.name)}</strong><p>${escapeHtml(msg.text)}</p></div>`).join("")}
    </div>
    <div class="suggests">
      <button class="chip" type="button" data-action="suggest" data-text="${escapeHtml(t("playground.suggest.can"))}">${escapeHtml(t("playground.suggest.can"))}</button>
      <button class="chip" type="button" data-action="suggest" data-text="${escapeHtml(t("playground.suggest.summary"))}">${escapeHtml(t("playground.suggest.summary"))}</button>
    </div>
    <form class="composer" data-form="chat">
      <label class="sr-only" for="chat-input">${escapeHtml(t("playground.input"))}</label>
      <input class="input" id="chat-input" name="message" placeholder="${escapeHtml(t("playground.placeholder"))}" autocomplete="off" />
      <button class="btn btn-primary" type="submit">${escapeHtml(t("playground.send"))}</button>
    </form>
    <p class="muted">${escapeHtml(t("playground.hint"))}</p>
  `;
}

export function defaultChat(model) {
  return [{ role: "assistant", text: t("playground.greeting", { name: model.name }) }];
}

export function playgroundReply(model, text) {
  const q = text.toLowerCase();
  if (q.includes("was kann") || q.includes("fähig")) {
    return t("playground.reply.capabilities", {
      name: model.name,
      type: typeLabel(model.type),
      base: model.baseModel,
    });
  }
  if (q.includes("zusammenfass") || q.includes("fasse")) {
    return t("playground.reply.summary");
  }
  return t("playground.reply.generic", { name: model.name });
}

function renderConnectors(state) {
  return `
    <p class="muted">${escapeHtml(t("connectors.body"))}</p>
    <p class="auth-demo">${escapeHtml(t("connectors.backendNeeded"))}</p>
    <div class="connector-grid">
      ${CONNECTORS.map((c) => connectorCard(c, state.connectors[c.id] || { connected: false, syncCount: 0 })).join("")}
    </div>
  `;
}

function connectorCard(def, st) {
  const connected = Boolean(st.connected);
  return `
    <article class="connector-card tone-${def.color === "coral" ? "coral" : def.color === "blue" ? "info" : def.color === "green" ? "success" : "gold"}">
      <header>
        <div>
          <h3>${escapeHtml(def.name)}</h3>
          <p class="muted">${escapeHtml(t("connectors.cat." + (def.category === "ai" ? "ai" : def.category === "hub" ? "hub" : "code")))}</p>
        </div>
        <span class="badge ${connected ? "badge-success" : ""}">${escapeHtml(connected ? t("connectors.connected") : t("connectors.disconnected"))}</span>
      </header>
      <p>${escapeHtml(t(def.descKey))}</p>
      <p class="muted">${escapeHtml(t(def.auth === "apiKey" ? "connectors.auth.apiKey" : "connectors.auth.oauth"))}</p>
      <div class="meta-row">
        <span>${escapeHtml(t("connectors.syncs", { n: st.syncCount || 0 }))}</span>
        <span>${escapeHtml(st.lastSync ? t("connectors.lastSync", { time: formatDateTime(st.lastSync) }) : t("connectors.never"))}</span>
      </div>
      <div class="card-actions">
        <button class="btn btn-primary" type="button" data-action="${connected ? "disconnect" : "connect"}" data-id="${def.id}">${escapeHtml(connected ? t("connectors.disconnect") : t("connectors.connect"))}</button>
        <button class="btn btn-secondary" type="button" data-action="sync" data-id="${def.id}">${escapeHtml(t("connectors.sync"))}</button>
        <a class="btn btn-ghost" href="${escapeHtml(def.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(t("connectors.website"))}</a>
      </div>
    </article>
  `;
}

function renderAdmin(state) {
  const s = stats();
  return `
    <p class="muted">${escapeHtml(t("admin.body"))}</p>
    <article class="stat-card tone-success">
      <header><span>${escapeHtml(t("admin.system"))}</span><span class="dot" aria-hidden="true"></span></header>
      <strong>${escapeHtml(t("admin.system"))}</strong>
    </article>
    <section class="stats-grid">
      ${statCard("users", formatNumber(s.users), t("admin.users"), t("admin.active"), "coral")}
      ${statCard("models", formatNumber(s.models), t("admin.models"), "", "info")}
      ${statCard("datasets", formatNumber(s.datasets), t("admin.datasets"), "", "success")}
      ${statCard("activity", formatNumber(s.activeRuns), t("admin.runs"), "", "gold")}
      ${statCard("globe", formatNumber(s.publicModels), t("admin.public"), "", "info")}
      ${statCard("check", formatNumber(s.validatedDatasets), t("admin.validated"), "", "success")}
    </section>
    <section>
      <h2>${escapeHtml(t("admin.userMgmt"))}</h2>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>${escapeHtml(t("common.name"))}</th>
              <th>${escapeHtml(t("common.email"))}</th>
              <th>${escapeHtml(t("admin.role"))}</th>
              <th>${escapeHtml(t("admin.status"))}</th>
              <th>${escapeHtml(t("admin.created"))}</th>
              <th>${escapeHtml(t("admin.changeRole"))}</th>
            </tr>
          </thead>
          <tbody>
            ${state.users.map(userRow).join("")}
          </tbody>
        </table>
        ${state.users.map(userCard).join("")}
      </div>
    </section>
    <section class="cms-grid">
      ${cmsCard("models", t("admin.catalog"), t("admin.catalogBody"), VIEWS.models)}
      ${cmsCard("datasets", t("admin.library"), t("admin.libraryBody"), VIEWS.datasets)}
      ${cmsCard("training", t("admin.training"), t("admin.trainingBody"), VIEWS.training)}
      ${cmsCard("activity", t("admin.log"), t("admin.logBody"), VIEWS.overview)}
    </section>
  `;
}

function userRow(user) {
  const me = currentUser();
  const locked = me && user.id === me.id && user.role === "admin";
  return `
    <tr>
      <td>${escapeHtml(user.name)}</td>
      <td>${escapeHtml(user.email)}</td>
      <td>${escapeHtml(t(user.role === "admin" ? "admin.role.admin" : "admin.role.member"))}</td>
      <td>${escapeHtml(user.status)}</td>
      <td>${escapeHtml(formatDate(user.createdAt))}</td>
      <td>
        <button class="btn btn-secondary" type="button" data-action="toggle-role" data-id="${user.id}" ${locked ? "disabled" : ""}>${escapeHtml(t("admin.changeRole"))}</button>
      </td>
    </tr>
  `;
}

function userCard(user) {
  const me = currentUser();
  const locked = me && user.id === me.id && user.role === "admin";
  return `
    <div class="user-row-card">
      <strong>${escapeHtml(user.name)}</strong>
      <span class="muted">${escapeHtml(user.email)}</span>
      <span>${escapeHtml(t(user.role === "admin" ? "admin.role.admin" : "admin.role.member"))}</span>
      <button class="btn btn-secondary" type="button" data-action="toggle-role" data-id="${user.id}" ${locked ? "disabled" : ""}>${escapeHtml(t("admin.changeRole"))}</button>
    </div>
  `;
}

function cmsCard(ico, title, body, view) {
  return `
    <article class="card">
      <div class="icon-wrap">${icon(ico)}</div>
      <h3>${escapeHtml(title)}</h3>
      <p class="muted">${escapeHtml(body)}</p>
      <button class="btn btn-secondary" type="button" data-action="nav" data-view="${view}">${escapeHtml(t("admin.open"))}</button>
    </article>
  `;
}

function renderForbidden() {
  return `
    <section class="forbidden card">
      <h2>${escapeHtml(t("admin.title"))}</h2>
      <p>${escapeHtml(t("admin.forbidden"))}</p>
      <button class="btn btn-primary" type="button" data-action="nav" data-view="${VIEWS.overview}">${escapeHtml(t("admin.back"))}</button>
    </section>
  `;
}

function renderSettings(state, user) {
  const n = state.settings.notifications;
  return `
    <p class="muted">${escapeHtml(t("settings.body"))}</p>
    <form class="settings-grid" data-form="settings">
      <article class="card stack">
        <label class="field">${escapeHtml(t("settings.workspace"))}
          <input class="input" name="workspace" value="${escapeHtml(state.settings.workspaceName)}" />
        </label>
        <label class="field">${escapeHtml(t("settings.user"))}
          <input class="input" name="username" value="${escapeHtml(user.name)}" />
        </label>
        <label class="field">${escapeHtml(t("settings.email"))}
          <input class="input" value="${escapeHtml(user.email)}" disabled />
        </label>
        <button class="btn btn-primary" type="submit">${escapeHtml(t("settings.save"))}</button>
      </article>
      <article class="card">
        <h3>${escapeHtml(t("settings.plan"))}</h3>
        <p>${escapeHtml(t("app.plan"))} · ${escapeHtml(t("app.demo"))}</p>
        <p class="muted">${escapeHtml(t("app.usage", { used: state.models.length, limit: state.settings.usageLimit }))}</p>
        <div class="card-actions">
          <button class="btn btn-secondary" type="button" data-action="coming-soon">${escapeHtml(t("settings.billing"))}</button>
          <button class="btn btn-secondary" type="button" data-action="coming-soon">${escapeHtml(t("settings.api"))}</button>
          <button class="btn btn-secondary" type="button" data-action="coming-soon">${escapeHtml(t("settings.team"))}</button>
        </div>
      </article>
      <article class="card">
        <h3>${escapeHtml(t("settings.notifications"))}</h3>
        ${switchRow("training", t("settings.notify.training"), n.training)}
        ${switchRow("datasets", t("settings.notify.datasets"), n.datasets)}
        ${switchRow("connectors", t("settings.notify.connectors"), n.connectors)}
      </article>
      <article class="card">
        <h3>${escapeHtml(t("settings.demo"))}</h3>
        <p class="muted">${escapeHtml(t("settings.demoBody"))}</p>
      </article>
      <button class="btn btn-danger" type="button" data-action="logout">${escapeHtml(t("settings.logout"))}</button>
    </form>
  `;
}

function switchRow(id, label, on) {
  return `
    <label class="switch">
      <span>${escapeHtml(label)}</span>
      <input type="checkbox" data-action="notify" data-id="${id}" ${on ? "checked" : ""} />
    </label>
  `;
}

function emptyBlock(text, action, cta, view) {
  const viewAttr = view ? ` data-view="${view}"` : "";
  return `<div class="empty card"><p>${escapeHtml(text)}</p><button class="btn btn-primary" type="button" data-action="${action}"${viewAttr}>${escapeHtml(cta)}</button></div>`;
}

function renderConfirm(confirm) {
  return `
    <div class="modal-backdrop" data-action="close-confirm">
      <div class="dialog" role="dialog" aria-modal="true">
        <h2>${escapeHtml(t(confirm.titleKey))}</h2>
        <div class="card-actions">
          <button class="btn btn-danger" type="button" data-action="${confirm.okAction}" data-id="${confirm.id}">${escapeHtml(t("common.delete"))}</button>
          <button class="btn btn-secondary" type="button" data-action="close-confirm">${escapeHtml(t("common.cancel"))}</button>
        </div>
      </div>
    </div>
  `;
}

export { formatPercent, formatNumber };
