const PATHS = {
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>',
  overview:
    '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
  models:
    '<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9L12 3z"/><path d="M12 12l8-4.5M12 12v9M12 12L4 7.5"/>',
  datasets:
    '<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v6c0 1.7 3.1 3 7 3s7-1.3 7-3V6M5 12v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/>',
  training:
    '<path d="M4 19V5"/><path d="M4 19h16"/><path d="M7 15l3.2-4 2.6 3 4.2-6"/>',
  playground:
    '<path d="M8 6l10 6-10 6V6z"/>',
  connectors:
    '<path d="M9 8H7a3 3 0 000 6h2"/><path d="M15 8h2a3 3 0 010 6h-2"/><path d="M9 12h6"/>',
  admin:
    '<path d="M12 3l7 3v5c0 4.4-2.9 8.4-7 9.5C7.9 19.4 5 15.4 5 11V6l7-3z"/>',
  settings:
    '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 01-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 01-4 0v-.2a1.7 1.7 0 00-1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 01-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 010-4h.2a1.7 1.7 0 001.5-1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 012.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 014 0v.2a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 012.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9c.3.6.9 1 1.5 1H21a2 2 0 010 4h-.2a1.7 1.7 0 00-1.4 1z"/>',
  download:
    '<path d="M12 4v12m0 0l-4.5-4.5M12 16l4.5-4.5M5 20h14"/>',
  logout: '<path d="M10 7V5a2 2 0 012-2h7v18h-7a2 2 0 01-2-2v-2"/><path d="M4 12h10M10 8l-4 4 4 4"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  search: '<circle cx="11" cy="11" r="6"/><path d="M16 16l4 4"/>',
  check: '<path d="M5 12l5 5L20 7"/>',
  alert:
    '<path d="M12 8v5"/><path d="M12 16.5h.01"/><path d="M10.3 4.7L2.8 18a2 2 0 001.7 3h15a2 2 0 001.7-3L13.7 4.7a2 2 0 00-3.4 0z"/>',
  cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 3v3M15 3v3M9 18v3M15 18v3M3 9h3M3 15h3M18 9h3M18 15h3"/>',
  gpu: '<rect x="4" y="7" width="16" height="10" rx="2"/><path d="M8 17v2M12 17v2M16 17v2M8 5v2M12 5v2M16 5v2"/>',
  upload:
    '<path d="M12 20V8m0 0l-4.5 4.5M12 8l4.5 4.5M5 4h14"/>',
  send: '<path d="M4 12l16-7-7 16-2-7-7-2z"/>',
  eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  users:
    '<circle cx="9" cy="8" r="3"/><path d="M3 19a6 6 0 0112 0"/><circle cx="17" cy="9" r="2.5"/><path d="M16 19a5 5 0 015-4"/>',
  spark:
    '<path d="M12 3v4M12 17v4M4.9 6.5l2.8 2.8M16.3 14.7l2.8 2.8M3 12h4M17 12h4M4.9 17.5l2.8-2.8M16.3 9.3l2.8-2.8"/>',
  clock: '<circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/>',
  chevron: '<path d="M9 6l6 6-6 6"/>',
  chevronLeft: '<path d="M15 6l-6 6 6 6"/>',
  external:
    '<path d="M14 5h5v5"/><path d="M19 5l-8 8"/><path d="M17 13v5a1 1 0 01-1 1H6a1 1 0 01-1-1V8a1 1 0 011-1h5"/>',
  sync: '<path d="M20 12a8 8 0 11-2.3-5.6L20 8"/><path d="M20 4v4h-4"/>',
  link: '<path d="M9 12H7a3 3 0 010-6h5"/><path d="M15 12h2a3 3 0 000-6h-5"/><path d="M8 12h8"/>',
  unlink:
    '<path d="M9 12H7a3 3 0 010-6h4"/><path d="M15 12h2a3 3 0 000-6h-4"/><path d="M4 20l16-16"/>',
  file: '<path d="M7 4h7l4 4v12a1 1 0 01-1 1H7a1 1 0 01-1-1V5a1 1 0 011-1z"/><path d="M14 4v5h5"/>',
  image:
    '<rect x="4" y="5" width="16" height="14" rx="2"/><circle cx="9" cy="10" r="1.5"/><path d="M4 16l4.5-4 4 3.5L16 13l4 3"/>',
  audio: '<path d="M9 8v8l-3 2V6l3 2zm0 0l8-3v14l-8-3"/>',
  layers:
    '<path d="M12 4l8 4-8 4-8-4 8-4z"/><path d="M4 12l8 4 8-4"/><path d="M4 16l8 4 8-4"/>',
  zap: '<path d="M13 3L5 13h7l-1 8 8-10h-7l1-8z"/>',
  lock: '<rect x="6" y="10" width="12" height="10" rx="2"/><path d="M8 10V8a4 4 0 018 0v2"/>',
  globe:
    '<circle cx="12" cy="12" r="8"/><path d="M4 12h16M12 4c2.5 2.6 3.8 5.4 3.8 8S14.5 17.4 12 20c-2.5-2.6-3.8-5.4-3.8-8S9.5 6.6 12 4z"/>',
  more: '<circle cx="6" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="18" cy="12" r="1.4"/>',
  filter:
    '<path d="M4 6h16M7 12h10M10 18h4"/>',
  arrowRight: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  shield:
    '<path d="M12 3l7 3v5c0 4.4-2.9 8.4-7 9.5C7.9 19.4 5 15.4 5 11V6l7-3z"/><path d="M9 12l2 2 4-4"/>',
  activity:
    '<path d="M4 12h3l2.5-6 4 12 2.5-6H20"/>',
  chat: '<path d="M5 6h14v9H8l-3 3V6z"/>',
  target:
    '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="1"/>',
  bolt: '<path d="M13 3L5 13h7l-1 8 8-10h-7l1-8z"/>',
  info: '<circle cx="12" cy="12" r="8"/><path d="M12 11v5M12 8h.01"/>',
  trash: '<path d="M5 7h14M10 7V5h4v2M8 7l1 13h6l1-13"/>',
  copy: '<rect x="8" y="8" width="11" height="11" rx="2"/><path d="M5 16V5h11"/>',
  star: '<path d="M12 4l2.4 4.9 5.4.8-3.9 3.8.9 5.4L12 16.8 7.2 18.9l.9-5.4-3.9-3.8 5.4-.8L12 4z"/>',
  calendar:
    '<rect x="4" y="6" width="16" height="14" rx="2"/><path d="M8 4v4M16 4v4M4 11h16"/>',
};

export function icon(name, options = {}) {
  const size = options.size || 20;
  const inner = PATHS[name] || PATHS.info;
  const cls = options.className ? ` class="${options.className}"` : "";
  const label = options.label
    ? ` role="img" aria-label="${escapeAttr(options.label)}"`
    : ' aria-hidden="true"';
  return `<svg${cls} width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"${label}>${inner}</svg>`;
}

function escapeAttr(value) {
  const amp = "\u0026";
  return String(value)
    .replaceAll("&", `${amp}amp;`)
    .replaceAll('"', `${amp}quot;`)
    .replaceAll("<", `${amp}lt;`);
}
