const FILE_LIST = [
  { path: "styles.css", url: "./styles.css" },
  { path: "main.js", url: "./main.js" },
  { path: "ui.js", url: "./ui.js" },
  { path: "state.js", url: "./state.js" },
  { path: "storage.js", url: "./storage.js" },
  { path: "data.js", url: "./data.js" },
  { path: "connectors.js", url: "./connectors.js" },
  { path: "icons.js", url: "./icons.js" },
  { path: "auth.js", url: "./auth.js" },
  { path: "export.js", url: "./export.js" },
  { path: "download-ui.js", url: "./download-ui.js" },
  { path: "manifest.json", url: "./manifest.json" },
  { path: "icon.svg", url: "./icon.svg" },
  { path: "sw.js", url: "./sw.js" },
  { path: "miniapp.i18n.json", url: "./miniapp.i18n.json" },
  { path: "locales/de.json", url: "./locales/de.json" },
  { path: "README.md", url: "./README.md" },
];

const INDEX_HTML = `<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#090d14" />
  <title>ForgeLab AI Model Studio</title>
  <link rel="icon" href="./icon.svg" type="image/svg+xml" />
  <link rel="manifest" href="./manifest.json" />
  <link rel="stylesheet" href="./styles.css" />
</head>
<body>
  <div id="app"></div>
  <script type="module" src="./main.js"></script>
</body>
</html>
`;

const README_FALLBACK = `# ForgeLab AI Model Studio

Statische Single-Page-App. Dateien mit einem lokalen HTTP-Server ausliefern.

Einige Quelldateien konnten beim Export nicht geladen werden. Die enthaltene README und index.html reichen zum Starten, sobald die restlichen Dateien ergänzt sind.
`;

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(bytes) {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function encodeUtf8(text) {
  return new TextEncoder().encode(text);
}

function u16(value) {
  const b = new Uint8Array(2);
  b[0] = value & 255;
  b[1] = (value >>> 8) & 255;
  return b;
}

function u32(value) {
  const b = new Uint8Array(4);
  b[0] = value & 255;
  b[1] = (value >>> 8) & 255;
  b[2] = (value >>> 16) & 255;
  b[3] = (value >>> 24) & 255;
  return b;
}

function concat(parts) {
  const size = parts.reduce((n, p) => n + p.length, 0);
  const out = new Uint8Array(size);
  let offset = 0;
  for (const part of parts) {
    out.set(part, offset);
    offset += part.length;
  }
  return out;
}

export function buildZip(files) {
  const locals = [];
  const centrals = [];
  let offset = 0;

  for (const file of files) {
    const nameBytes = encodeUtf8(file.name);
    const data = file.data instanceof Uint8Array ? file.data : encodeUtf8(String(file.data || ""));
    const crc = crc32(data);
    const local = concat([
      u32(0x04034b50),
      u16(20),
      u16(0x0800),
      u16(0),
      u16(0),
      u16(0),
      u32(crc),
      u32(data.length),
      u32(data.length),
      u16(nameBytes.length),
      u16(0),
      nameBytes,
      data,
    ]);
    const central = concat([
      u32(0x02014b50),
      u16(20),
      u16(20),
      u16(0x0800),
      u16(0),
      u16(0),
      u16(0),
      u32(crc),
      u32(data.length),
      u32(data.length),
      u16(nameBytes.length),
      u16(0),
      u16(0),
      u16(0),
      u16(0),
      u32(0),
      u32(offset),
      nameBytes,
    ]);
    locals.push(local);
    centrals.push(central);
    offset += local.length;
  }

  const localBlob = concat(locals);
  const centralBlob = concat(centrals);
  const eocd = concat([
    u32(0x06054b50),
    u16(0),
    u16(0),
    u16(files.length),
    u16(files.length),
    u32(centralBlob.length),
    u32(localBlob.length),
    u16(0),
  ]);
  return new Blob([localBlob, centralBlob, eocd], { type: "application/zip" });
}

async function fetchBinary(rel) {
  const url = new URL(rel, import.meta.url);
  const res = await fetch(url, { cache: "no-store" });
  if (!res.ok) throw new Error("missing");
  return new Uint8Array(await res.arrayBuffer());
}

let prepared = null;
let preparePromise = null;

export function getPreparedZip() {
  return prepared;
}

export async function prepareProjectZip() {
  if (prepared) return prepared;
  if (preparePromise) return preparePromise;
  preparePromise = (async () => {
    const files = [{ name: "index.html", data: encodeUtf8(INDEX_HTML) }];
    let missing = 0;
    const results = await Promise.all(
      FILE_LIST.map(async (item) => {
        try {
          const data = await fetchBinary(item.url);
          return { name: item.path, data };
        } catch {
          missing += 1;
          return null;
        }
      }),
    );
    for (const item of results) if (item) files.push(item);
    const hasReadme = files.some((f) => f.name === "README.md");
    if (!hasReadme) files.push({ name: "README.md", data: encodeUtf8(README_FALLBACK) });
    const blob = buildZip(files);
    const url = URL.createObjectURL(blob);
    prepared = {
      blob,
      url,
      filename: "forgelab-ai-model-studio.zip",
      missing,
    };
    return prepared;
  })();
  try {
    return await preparePromise;
  } catch {
    const files = [
      { name: "index.html", data: encodeUtf8(INDEX_HTML) },
      { name: "README.md", data: encodeUtf8(README_FALLBACK) },
    ];
    const blob = buildZip(files);
    prepared = {
      blob,
      url: URL.createObjectURL(blob),
      filename: "forgelab-ai-model-studio.zip",
      missing: FILE_LIST.length,
    };
    return prepared;
  } finally {
    preparePromise = null;
  }
}
