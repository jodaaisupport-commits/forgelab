import { readJson, writeJson } from "./storage.js";
import {
  STORAGE_KEYS,
  VIEWS,
  STATUS,
  seedModels,
  seedDatasets,
  seedRuns,
  seedActivities,
  seedSettings,
  emptyWizard,
  uid,
  nowIso,
  BASE_MODELS,
} from "./data.js";
import { seedConnectorState } from "./connectors.js";

const listeners = new Set();
let bundle = null;
let persistTimer = null;
let trainingTimer = null;
let hydrateWarning = false;

function defaultBundle() {
  return {
    users: [],
    session: null,
    view: VIEWS.overview,
    models: seedModels(),
    datasets: seedDatasets(),
    runs: seedRuns(),
    activities: seedActivities(),
    connectors: seedConnectorState(),
    settings: seedSettings(),
    chats: {},
    wizard: emptyWizard(),
    ui: {
      sidebarOpen: false,
      modelQuery: "",
      modelStatus: "all",
      selectedModelId: null,
      playgroundModelId: "model_aurora",
      playgroundTemp: 0.7,
      playgroundTokens: 512,
      authMode: "login",
      toasts: [],
    },
    initialized: true,
  };
}

export function getState() {
  return bundle;
}

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function notify() {
  for (const fn of listeners) fn(bundle);
}

export function patch(mutator) {
  mutator(bundle);
  notify();
  schedulePersist();
}

function schedulePersist() {
  if (persistTimer) clearTimeout(persistTimer);
  persistTimer = setTimeout(() => {
    persistTimer = null;
    void persist();
  }, 180);
}

export async function persist() {
  if (!bundle) return;
  const snapshot = {
    users: bundle.users,
    session: bundle.session,
    view: bundle.view,
    models: bundle.models,
    datasets: bundle.datasets,
    runs: bundle.runs,
    activities: bundle.activities,
    connectors: bundle.connectors,
    settings: bundle.settings,
    chats: bundle.chats,
    ui: {
      modelQuery: bundle.ui.modelQuery,
      modelStatus: bundle.ui.modelStatus,
      selectedModelId: bundle.ui.selectedModelId,
      playgroundModelId: bundle.ui.playgroundModelId,
      playgroundTemp: bundle.ui.playgroundTemp,
      playgroundTokens: bundle.ui.playgroundTokens,
      authMode: bundle.ui.authMode,
    },
    initialized: true,
  };
  try {
    await writeJson(STORAGE_KEYS.bundle, snapshot);
  } catch {
    /* keep memory state */
  }
}

export async function hydrate() {
  const loaded = await readJson(STORAGE_KEYS.bundle, null);
  if (loaded?.__corrupt) {
    hydrateWarning = true;
    bundle = defaultBundle();
    return { warning: true };
  }
  if (!loaded || typeof loaded !== "object" || !loaded.initialized) {
    bundle = defaultBundle();
    await persist();
    return { warning: false };
  }
  const base = defaultBundle();
  bundle = {
    ...base,
    ...loaded,
    ui: { ...base.ui, ...(loaded.ui || {}) },
    settings: { ...base.settings, ...(loaded.settings || {}) },
    connectors: { ...base.connectors, ...(loaded.connectors || {}) },
    wizard: emptyWizard(),
  };
  if (!Array.isArray(bundle.users)) bundle.users = [];
  if (!Array.isArray(bundle.models)) bundle.models = seedModels();
  if (!Array.isArray(bundle.datasets)) bundle.datasets = seedDatasets();
  if (!Array.isArray(bundle.runs)) bundle.runs = seedRuns();
  return { warning: hydrateWarning };
}

export function hadHydrateWarning() {
  return hydrateWarning;
}

export function currentUser() {
  if (!bundle?.session?.userId) return null;
  return bundle.users.find((u) => u.id === bundle.session.userId) || null;
}

export function isAdmin() {
  return currentUser()?.role === "admin";
}

export function setView(view) {
  patch((s) => {
    s.view = view;
    s.ui.sidebarOpen = false;
  });
}

export function pushToast(message, tone = "info", vars = {}) {
  const toast = { id: uid("toast"), message, tone, vars };
  patch((s) => {
    s.ui.toasts = [...s.ui.toasts, toast].slice(-4);
  });
  setTimeout(() => {
    patch((s) => {
      s.ui.toasts = s.ui.toasts.filter((item) => item.id !== toast.id);
    });
  }, 4200);
}

export function pushActivity(key, tone = "info") {
  patch((s) => {
    s.activities = [
      { id: uid("act"), key, at: nowIso(), tone },
      ...s.activities,
    ].slice(0, 20);
  });
}

export function startTrainingLoop() {
  if (trainingTimer) return;
  trainingTimer = setInterval(() => {
    if (!bundle) return;
    let changed = false;
    let completed = [];
    for (const run of bundle.runs) {
      if (run.status !== STATUS.running) continue;
      changed = true;
      const step = 1.8 + Math.random() * 3.4;
      run.progress = Math.min(100, Number((run.progress + step).toFixed(1)));
      const started = new Date(run.startedAt).getTime();
      run.durationMin = Math.max(1, Math.round((Date.now() - started) / 60000) || 1);
      const t = run.progress / 100;
      const target = run.targetAccuracy || 92;
      const startAcc = run.startAccuracy ?? Math.max(40, (run.accuracy || 70) - 12);
      run.startAccuracy = startAcc;
      run.accuracy = Number((startAcc + (target - startAcc) * t).toFixed(1));
      const startLoss = run.startLoss ?? Math.max(0.4, (run.loss || 0.5) + 0.2);
      run.startLoss = startLoss;
      run.loss = Number((startLoss + (0.08 - startLoss) * t).toFixed(3));
      if (run.progress >= 100) {
        run.status = STATUS.completed;
        run.progress = 100;
        run.finishedAt = nowIso();
        const model = bundle.models.find((m) => m.id === run.modelId);
        if (model) {
          model.status = STATUS.ready;
          model.accuracy = run.accuracy;
          model.updatedAt = nowIso();
        }
        completed.push(run);
      }
    }
    if (changed) {
      schedulePersist();
      globalThis.dispatchEvent(new CustomEvent("forgelab:progress", { detail: bundle.runs }));
    }
    if (completed.length) {
      for (const run of completed) {
        void run;
        pushToast("toast.trainingDone", "success");
        pushActivity("activity.trainingFinished", "success");
      }
      notify();
    }
  }, 900);
}

export function createTrainingFromWizard(wizard) {
  const base = BASE_MODELS.find((b) => b.id === wizard.baseModelId) || BASE_MODELS[0];
  const modelId = uid("model");
  const version = "v0.1";
  const model = {
    id: modelId,
    name: wizard.name.trim(),
    description: wizard.description.trim(),
    type: wizard.type,
    baseModelId: base.id,
    baseModel: base.name,
    status: STATUS.training,
    version,
    accuracy: 42,
    visibility: wizard.visibility,
    downloads: 0,
    updatedAt: nowIso(),
    createdAt: nowIso(),
    epochs: Number(wizard.epochs) || 3,
    learningRate: wizard.learningRate,
    hardware: wizard.hardware,
    datasetIds: [...wizard.datasetIds],
  };
  const run = {
    id: uid("run"),
    modelId,
    modelName: model.name,
    version,
    status: STATUS.running,
    progress: 4,
    loss: 1.12,
    accuracy: 42,
    durationMin: 0,
    hardware: wizard.hardware,
    startedAt: nowIso(),
    finishedAt: null,
    targetAccuracy: 88 + Math.random() * 8,
    startAccuracy: 42,
    startLoss: 1.12,
  };
  patch((s) => {
    s.models = [model, ...s.models];
    s.runs = [run, ...s.runs];
    s.view = VIEWS.training;
    s.wizard = emptyWizard();
    s.settings.usageModels = s.models.length;
  });
  pushActivity("activity.trainingStarted", "info");
  return { model, run };
}

export function addDatasetFromFile(file, kind, quality) {
  const dataset = {
    id: uid("ds"),
    name: file.name.replace(/\.[^.]+$/, ""),
    fileName: file.name,
    format: kind.format,
    kind: kind.kind,
    rows: kind.kind === "image" ? 1 : Math.max(12, Math.round(file.size / 48)),
    files: 1,
    quality,
    sizeBytes: file.size,
    status: "validated",
    createdAt: nowIso(),
  };
  patch((s) => {
    s.datasets = [dataset, ...s.datasets];
  });
  return dataset;
}

export function stats() {
  const s = bundle;
  const best = s.models.reduce((m, x) => Math.max(m, x.accuracy || 0), 0);
  return {
    models: s.models.length,
    datasets: s.datasets.length,
    runs: s.runs.length,
    bestAccuracy: best,
    publicModels: s.models.filter((m) => m.visibility === "public").length,
    validatedDatasets: s.datasets.filter((d) => d.status === "validated").length,
    activeRuns: s.runs.filter((r) => r.status === STATUS.running).length,
    users: s.users.length,
  };
}
