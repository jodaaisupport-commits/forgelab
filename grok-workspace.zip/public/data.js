export const STORAGE_KEYS = {
  bundle: "bundle",
};

export const VIEWS = {
  overview: "overview",
  models: "models",
  datasets: "datasets",
  training: "training",
  playground: "playground",
  connectors: "connectors",
  admin: "admin",
  settings: "settings",
  wizard: "wizard",
  modelDetail: "modelDetail",
};

export const MODEL_TYPES = [
  { id: "text", labelKey: "types.text" },
  { id: "vision", labelKey: "types.vision" },
  { id: "audio", labelKey: "types.audio" },
  { id: "classification", labelKey: "types.classification" },
  { id: "embeddings", labelKey: "types.embeddings" },
];

export const BASE_MODELS = [
  {
    id: "llama-8b",
    name: "Llama 3.1 8B",
    vendor: "Meta",
    type: "text",
    descKey: "bases.llama",
  },
  {
    id: "mistral-7b",
    name: "Mistral 7B",
    vendor: "Mistral",
    type: "text",
    descKey: "bases.mistral",
  },
  {
    id: "gemma-9b",
    name: "Gemma 2 9B",
    vendor: "Google",
    type: "text",
    descKey: "bases.gemma",
  },
  {
    id: "llava-16",
    name: "LLaVA 1.6",
    vendor: "LLaVA",
    type: "vision",
    descKey: "bases.llava",
  },
  {
    id: "whisper-large",
    name: "Whisper large-v3",
    vendor: "OpenAI",
    type: "audio",
    descKey: "bases.whisper",
  },
  {
    id: "distilbert",
    name: "DistilBERT",
    vendor: "Hugging Face",
    type: "classification",
    descKey: "bases.distilbert",
  },
];

export const HARDWARE = [
  { id: "cpu", labelKey: "hardware.cpu", hintKey: "hardware.cpuHint" },
  { id: "gpu", labelKey: "hardware.gpu", hintKey: "hardware.gpuHint" },
];

export const ROLES = {
  admin: "admin",
  member: "member",
};

export const STATUS = {
  ready: "ready",
  training: "training",
  completed: "completed",
  failed: "failed",
  running: "running",
};

export function nowIso() {
  return new Date().toISOString();
}

export function uid(prefix = "id") {
  if (globalThis.crypto?.randomUUID) return `${prefix}_${crypto.randomUUID()}`;
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export function seedModels() {
  return [
    {
      id: "model_aurora",
      name: "Aurora Support",
      descKey: "seed.models.aurora.desc",
      type: "text",
      baseModelId: "llama-8b",
      baseModel: "Llama 3.1 8B",
      status: STATUS.ready,
      version: "v1.4",
      accuracy: 94.2,
      visibility: "private",
      downloads: 1280,
      updatedAt: "2026-09-18T09:12:00.000Z",
      createdAt: "2026-06-02T10:00:00.000Z",
    },
    {
      id: "model_vision",
      name: "Vision Scout",
      descKey: "seed.models.vision.desc",
      type: "vision",
      baseModelId: "llava-16",
      baseModel: "LLaVA 1.6",
      status: STATUS.training,
      version: "v0.3",
      accuracy: 81.0,
      visibility: "private",
      downloads: 342,
      updatedAt: "2026-09-23T16:40:00.000Z",
      createdAt: "2026-08-14T08:30:00.000Z",
    },
    {
      id: "model_mint",
      name: "Mint Classifier",
      descKey: "seed.models.mint.desc",
      type: "classification",
      baseModelId: "distilbert",
      baseModel: "DistilBERT",
      status: STATUS.ready,
      version: "v2.0",
      accuracy: 97.4,
      visibility: "public",
      downloads: 8900,
      updatedAt: "2026-09-12T14:20:00.000Z",
      createdAt: "2026-04-21T11:15:00.000Z",
    },
  ];
}

export function seedDatasets() {
  return [
    {
      id: "ds_support",
      name: "Support conversations",
      format: "JSONL",
      kind: "jsonl",
      rows: 12480,
      files: 1,
      quality: 96,
      sizeBytes: 8.4 * 1024 * 1024,
      status: "validated",
      createdAt: "2026-05-03T09:00:00.000Z",
    },
    {
      id: "ds_photos",
      name: "Product photos",
      format: "Bilder",
      kind: "image",
      rows: 4200,
      files: 4200,
      quality: 89,
      sizeBytes: 1.8 * 1024 * 1024 * 1024,
      status: "validated",
      createdAt: "2026-07-19T12:40:00.000Z",
    },
    {
      id: "ds_intents",
      name: "Intent labels",
      format: "CSV",
      kind: "csv",
      rows: 3840,
      files: 1,
      quality: 100,
      sizeBytes: 1.2 * 1024 * 1024,
      status: "validated",
      createdAt: "2026-06-28T15:10:00.000Z",
    },
  ];
}

export function seedRuns() {
  return [
    {
      id: "run_aurora",
      modelId: "model_aurora",
      modelName: "Aurora Support",
      version: "v1.4",
      status: STATUS.completed,
      progress: 100,
      loss: 0.184,
      accuracy: 94.2,
      durationMin: 24,
      hardware: "gpu",
      startedAt: "2026-09-18T08:48:00.000Z",
      finishedAt: "2026-09-18T09:12:00.000Z",
    },
    {
      id: "run_vision",
      modelId: "model_vision",
      modelName: "Vision Scout",
      version: "v0.3",
      status: STATUS.running,
      progress: 68,
      loss: 0.392,
      accuracy: 81.0,
      durationMin: 18,
      hardware: "gpu",
      startedAt: "2026-09-23T16:22:00.000Z",
      finishedAt: null,
      targetAccuracy: 88,
    },
    {
      id: "run_mint",
      modelId: "model_mint",
      modelName: "Mint Classifier",
      version: "v2.0",
      status: STATUS.completed,
      progress: 100,
      loss: 0.091,
      accuracy: 97.4,
      durationMin: 11,
      hardware: "cpu",
      startedAt: "2026-09-12T14:09:00.000Z",
      finishedAt: "2026-09-12T14:20:00.000Z",
    },
  ];
}

export function seedActivities() {
  return [
    {
      id: "act_1",
      key: "activity.auroraUpdated",
      at: "2026-09-18T09:12:00.000Z",
      tone: "success",
    },
    {
      id: "act_2",
      key: "activity.visionStarted",
      at: "2026-09-23T16:22:00.000Z",
      tone: "info",
    },
    {
      id: "act_3",
      key: "activity.photosValidated",
      at: "2026-09-20T11:04:00.000Z",
      tone: "success",
    },
    {
      id: "act_4",
      key: "activity.mintPublished",
      at: "2026-09-12T14:22:00.000Z",
      tone: "info",
    },
    {
      id: "act_5",
      key: "activity.connectorGithub",
      at: "2026-09-08T17:40:00.000Z",
      tone: "neutral",
    },
  ];
}

export function seedSettings() {
  return {
    workspaceName: "Meine Werkstatt",
    plan: "starter",
    planStatus: "demo",
    usageModels: 3,
    usageLimit: 10,
    renewsAt: "2026-10-23",
    notifications: {
      training: true,
      datasets: true,
      connectors: false,
    },
  };
}

export function emptyWizard() {
  return {
    step: 1,
    name: "",
    description: "",
    type: "text",
    baseModelId: "llama-8b",
    datasetIds: ["ds_support"],
    epochs: 3,
    learningRate: "2e-5",
    visibility: "private",
    hardware: "cpu",
  };
}

export function detectFileKind(file) {
  const name = (file.name || "").toLowerCase();
  const type = (file.type || "").toLowerCase();
  if (name.endsWith(".jsonl") || type.includes("jsonl")) return { format: "JSONL", kind: "jsonl" };
  if (name.endsWith(".json") || type.includes("json")) return { format: "JSON", kind: "json" };
  if (name.endsWith(".csv") || type.includes("csv")) return { format: "CSV", kind: "csv" };
  if (name.endsWith(".txt") || type.includes("text")) return { format: "TXT", kind: "txt" };
  if (type.startsWith("image/") || /\.(png|jpe?g|gif|webp|bmp)$/.test(name)) {
    return { format: "Bilder", kind: "image" };
  }
  return { format: "Datei", kind: "file" };
}

export const MAX_UPLOAD_BYTES = 50 * 1024 * 1024;
