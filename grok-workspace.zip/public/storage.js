const DB_NAME = "forgelab-studio";
const STORE = "kv";
const PREFIX = "forgelab:";

function getMiniStorage() {
  const g = globalThis;
  const candidates = [
    g.miniapp?.storage,
    g.Miniapp?.storage,
    g.miniappStorage,
    g.grok?.storage,
    g.__MINIAPP_STORAGE__,
  ];
  for (const candidate of candidates) {
    if (
      candidate &&
      typeof candidate.getItem === "function" &&
      typeof candidate.setItem === "function"
    ) {
      if (candidate === g.localStorage || candidate === g.sessionStorage) continue;
      return candidate;
    }
  }
  return null;
}

let dbPromise = null;

function openDb() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    if (!("indexedDB" in globalThis)) {
      reject(new Error("indexedDB unavailable"));
      return;
    }
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("idb open failed"));
  });
  return dbPromise;
}

function idbGet(key) {
  return openDb().then(
    (db) =>
      new Promise((resolve, reject) => {
        const tx = db.transaction(STORE, "readonly");
        const req = tx.objectStore(STORE).get(key);
        req.onsuccess = () => resolve(req.result ?? null);
        req.onerror = () => reject(req.error);
      }),
  );
}

function idbSet(key, value) {
  return openDb().then(
    (db) =>
      new Promise((resolve, reject) => {
        const tx = db.transaction(STORE, "readwrite");
        tx.objectStore(STORE).put(value, key);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      }),
  );
}

function idbRemove(key) {
  return openDb().then(
    (db) =>
      new Promise((resolve, reject) => {
        const tx = db.transaction(STORE, "readwrite");
        tx.objectStore(STORE).delete(key);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      }),
  );
}

const memory = new Map();

function memoryGet(key) {
  return memory.has(key) ? memory.get(key) : null;
}

export async function getItem(key) {
  const full = PREFIX + key;
  const mini = getMiniStorage();
  try {
    if (mini) {
      const value = await mini.getItem(full);
      if (value === undefined) return null;
      return value;
    }
  } catch {
    /* fall through */
  }
  try {
    return await idbGet(full);
  } catch {
    return memoryGet(full);
  }
}

export async function setItem(key, value) {
  const full = PREFIX + key;
  const mini = getMiniStorage();
  memory.set(full, value);
  try {
    if (mini) {
      await mini.setItem(full, value);
      return;
    }
  } catch {
    /* fall through */
  }
  try {
    await idbSet(full, value);
  } catch {
    /* memory already set */
  }
}

export async function removeItem(key) {
  const full = PREFIX + key;
  const mini = getMiniStorage();
  memory.delete(full);
  try {
    if (mini && typeof mini.removeItem === "function") {
      await mini.removeItem(full);
      return;
    }
  } catch {
    /* fall through */
  }
  try {
    await idbRemove(full);
  } catch {
    /* ignore */
  }
}

export async function readJson(key, fallback) {
  try {
    const raw = await getItem(key);
    if (raw == null || raw === "") return fallback;
    if (typeof raw === "object") return raw;
    return JSON.parse(String(raw));
  } catch {
    return { __corrupt: true, value: fallback };
  }
}

export async function writeJson(key, value) {
  await setItem(key, JSON.stringify(value));
}
