import { nowIso } from "./data.js";

export const CONNECTORS = [
  {
    id: "dahl",
    name: "dahl.global",
    category: "ai",
    auth: "apiKey",
    descKey: "connectors.dahl.desc",
    color: "coral",
    url: "https://dahl.global",
  },
  {
    id: "github",
    name: "GitHub",
    category: "code",
    auth: "oauth",
    descKey: "connectors.github.desc",
    color: "blue",
    url: "https://github.com",
  },
  {
    id: "gitlab",
    name: "GitLab",
    category: "code",
    auth: "oauth",
    descKey: "connectors.gitlab.desc",
    color: "gold",
    url: "https://gitlab.com",
  },
  {
    id: "bitbucket",
    name: "Bitbucket",
    category: "code",
    auth: "oauth",
    descKey: "connectors.bitbucket.desc",
    color: "green",
    url: "https://bitbucket.org",
  },
  {
    id: "huggingface",
    name: "Hugging Face",
    category: "hub",
    auth: "apiKey",
    descKey: "connectors.huggingface.desc",
    color: "gold",
    url: "https://huggingface.co",
  },
];

export function seedConnectorState() {
  const state = {};
  for (const item of CONNECTORS) {
    state[item.id] = {
      connected: false,
      syncCount: 0,
      lastSync: null,
    };
  }
  return state;
}

export function connectConnector(state, id) {
  const current = state[id] || { connected: false, syncCount: 0, lastSync: null };
  return {
    ...state,
    [id]: { ...current, connected: true },
  };
}

export function disconnectConnector(state, id) {
  return {
    ...state,
    [id]: { connected: false, syncCount: 0, lastSync: null },
  };
}

export function syncConnector(state, id) {
  const current = state[id];
  if (!current?.connected) return { ok: false, state };
  return {
    ok: true,
    state: {
      ...state,
      [id]: {
        ...current,
        syncCount: (current.syncCount || 0) + 1,
        lastSync: nowIso(),
      },
    },
  };
}
