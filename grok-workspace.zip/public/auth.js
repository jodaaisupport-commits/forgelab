import { ROLES, uid, nowIso } from "./data.js";

function bytesToHex(buffer) {
  return [...new Uint8Array(buffer)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function hexToBytes(hex) {
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.substr(i * 2, 2), 16);
  return out;
}

function randomSalt() {
  const salt = new Uint8Array(16);
  crypto.getRandomValues(salt);
  return bytesToHex(salt);
}

export async function hashPassword(password, saltHex) {
  const enc = new TextEncoder();
  const salt = hexToBytes(saltHex);
  if (globalThis.crypto?.subtle) {
    const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, [
      "deriveBits",
    ]);
    const bits = await crypto.subtle.deriveBits(
      { name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" },
      key,
      256,
    );
    return bytesToHex(bits);
  }
  let h = 2166136261;
  const mixed = password + saltHex;
  for (let i = 0; i < mixed.length; i++) {
    h ^= mixed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16).padStart(8, "0");
}

export async function verifyPassword(password, user) {
  const hash = await hashPassword(password, user.salt);
  return hash === user.passwordHash;
}

export function validateRegister({ name, email, password, confirm }) {
  const errors = {};
  if (!name?.trim()) errors.name = "auth.error.required";
  if (!email?.trim()) errors.email = "auth.error.required";
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) errors.email = "auth.error.email";
  if (!password) errors.password = "auth.error.required";
  else if (password.length < 8) errors.password = "auth.error.shortPassword";
  if (!confirm) errors.confirm = "auth.error.required";
  else if (password !== confirm) errors.confirm = "auth.error.mismatch";
  return errors;
}

export function validateLogin({ email, password }) {
  const errors = {};
  if (!email?.trim()) errors.email = "auth.error.required";
  if (!password) errors.password = "auth.error.required";
  return errors;
}

export async function createUser({ name, email, password, isFirst }) {
  const salt = randomSalt();
  const passwordHash = await hashPassword(password, salt);
  return {
    id: uid("user"),
    name: name.trim(),
    email: email.trim().toLowerCase(),
    passwordHash,
    salt,
    role: isFirst ? ROLES.admin : ROLES.member,
    status: "active",
    createdAt: nowIso(),
  };
}

export function publicUser(user) {
  if (!user) return null;
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    status: user.status,
    createdAt: user.createdAt,
  };
}

export function findUserByEmail(users, email) {
  const needle = String(email || "")
    .trim()
    .toLowerCase();
  return users.find((u) => u.email === needle) || null;
}
