# ForgeLab AI Model Studio

Frontend-Simulation eines AI-Model-Studios. Deutschsprachige Single-Page-App ohne große Frameworks.

## Enthalten

- Konto (Registrierung / Anmeldung, erstes Konto = Administrator)
- Übersicht, Modelle, Datensätze, Training, Playground
- Connector-Hub (Demo-Status, keine API-Keys)
- Admin CMS (rollengeschützt)
- ZIP-Export dieses Projekts
- Persistenz über Miniapp-Speicher-API oder IndexedDB (kein localStorage)

## Starten

Diese Dateien als statische Website ausliefern (kein `file://` für ES-Module):

```bash
python3 -m http.server 8080
```

Dann `index.html` im Browser öffnen.

## Hinweise

- Authentifizierung, Inferenz und OAuth sind Demo-Flüsse. Produktiv ist ein Backend nötig.
- Passwörter werden mit Web Crypto (PBKDF2) gehasht.
- Der Service Worker nutzt Netzwerk zuerst und Cache als Fallback.
